import AwsJwtCognito.AwsCognitoJwtValidatorUtil;
import com.amazonaws.util.Base64;
import com.nimbusds.jwt.JWTClaimsSet;

import java.security.interfaces.RSAPublicKey;

public class Token {
    JWTClaimsSet claims;
    public Token (String authHeader) {
        try{
            System.out.println("AUTHENTICATING TOKEN...");
            claims = AwsCognitoJwtValidatorUtil.validateAWSJwtToken(authHeader);
            System.out.println(claims.getClaims());
            System.out.println(claims.getClaim("username") + " is authenticated.");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
