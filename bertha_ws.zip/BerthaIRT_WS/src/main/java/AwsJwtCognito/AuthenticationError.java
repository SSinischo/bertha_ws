package AwsJwtCognito;

/**
 * Created by rohitkumar on 24/03/18.
 */
public class AuthenticationError {
    public static final String NOT_VALID_JSON_WEB_TOKEN = "Not a valid json web token";
    public static final String TOKEN_EXPIRED = " Aws Jwt Token has expired.";
}
