import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.AWSCredentialsProvider;
import com.amazonaws.auth.DefaultAWSCredentialsProviderChain;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.cognitoidp.AWSCognitoIdentityProvider;
import com.amazonaws.services.cognitoidp.AWSCognitoIdentityProviderClientBuilder;
import com.amazonaws.services.cognitoidp.model.*;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClientBuilder;
import com.amazonaws.services.dynamodbv2.document.*;
import io.javalin.Handler;
import io.javalin.Javalin;
import java.util.*;


public class WebServiceMain {
    static AWSCognitoIdentityProvider idp;
    static DynamoDB db;
    static String pid = "us-east-1_1abyUmkI0";
    static Token userToken;

    public static void main(String[] args) {
        Javalin app = Javalin.create().start(80);
        AWSCredentialsProvider p = new DefaultAWSCredentialsProviderChain();
        AWSCognitoIdentityProviderClientBuilder bidp = AWSCognitoIdentityProviderClientBuilder.standard();
        bidp.withRegion(Regions.US_EAST_1);
        bidp.withCredentials(p);
        idp = bidp.build();

        AmazonDynamoDBClientBuilder bdb = AmazonDynamoDBClientBuilder.standard();
        bdb.withRegion(Regions.US_EAST_1);
        bdb.withCredentials(p);
        db = new DynamoDB(bdb.build());

        String header;

        app.before(ctx->{
            System.out.println(ctx.headerMap());
            String auth = ctx.header("Authorization");
            if(auth != null)
                userToken = new Token(auth);
            //System.out.println(ctx.body());
            //System.out.println(ctx.formParamMap());
        });

        app.post("/newgroup", ctx -> {
            System.out.println("HERE");
            ctx.status(createGroup(ctx.formParam("name"), ctx.formParam("email")));
        });

        app.get("/admin/portaldata/:email", ctx -> {
            Map<String, String> map = new HashMap<>();
            map.put("name", findAdminName(ctx.pathParam("email")));
            map.put("groupid", findGroupCode(ctx.pathParam("email")));
            map.put("group", findGroupName(map.get("groupid")));
            ctx.json(map);
        });

        app.get("/admin/update_attributes", ctx -> {
            setUserPassword(ctx.queryParam("user"), ctx.queryParam("pass"));
            setUserRealName(ctx.queryParam("user"), ctx.queryParam("name"));
            ctx.result("OK");
        });

        app.get("/newstudent/:group", ctx -> ctx.result(matchGroup(ctx.pathParam("group"))));
        app.get("/find_owned_group/:email", ctx -> ctx.result(findGroupCode(ctx.pathParam("email"))));

    }

    private static void setUserPassword(String user, String pass) {
        if(pass.equals("")) return;
        if(!user.equals(userToken.claims.getClaim("username"))) return;
        idp.changePassword(new ChangePasswordRequest().);
    }

    private static void setUserRealName(String user, String name) {
        authenticateUser
    }

    private static int createGroup(String name, String adminEmail) {
        System.out.println("name" + name);
        System.out.println("email" + adminEmail);
        int ACCESS_CODE_LENGTH = 8;
        String ACCESS_CODE_CHARS = "0123456789ABCDEF";

        Table t = db.getTable("group");

        StringBuilder sb = new StringBuilder();
        while (sb.length() < ACCESS_CODE_LENGTH)
            sb.append(ACCESS_CODE_CHARS.charAt((int) (new Random().nextFloat() * ACCESS_CODE_CHARS.length())));
        String newCode = sb.toString();
        String[] newAdmins = new String[1];
        newAdmins[0] = adminEmail;

        PutItemOutcome outcome = t.putItem(new Item().withPrimaryKey("id", newCode).withString("name", name).withStringSet("admins", newAdmins));
        System.out.println("PutItem succeeded:\n" + outcome.getPutItemResult());
        AdminCreateUserResult res = idp.adminCreateUser(new AdminCreateUserRequest()
                .withUserPoolId(pid)
                .withUsername(adminEmail)
		.withTemporaryPassword("696969")
                .withUserAttributes(
                        new AttributeType().withName("custom:groupID").withValue(newCode),
                        new AttributeType().withName("email").withValue(adminEmail))
                .withDesiredDeliveryMediums(DeliveryMediumType.EMAIL));
        return 200;
    }

    private static String matchGroup(String group) {
        if (group.equals("1000"))
            return "University of Alabama";
        if (group.equals("1001"))
            return "Saban Prepatory Academy for Football Sciences";
        if (group.equals("1002"))
            return "fuckboi school";
        return "NONE";
    }

    private static String findGroupCode(String email) {
        AdminGetUserResult r = idp.adminGetUser(new AdminGetUserRequest().withUsername(email).withUserPoolId(pid));
        List<AttributeType> code = r.getUserAttributes();
        Iterator i = code.iterator();
        while(i.hasNext()){
            AttributeType a = (AttributeType) i.next();
            if(a.getName().equals("custom:groupID"))
                return a.getValue();
        }
        return "NONE";
    }

    private static String findAdminName(String email){
        AdminGetUserResult r = idp.adminGetUser(new AdminGetUserRequest().withUsername(email).withUserPoolId(pid));
        List<AttributeType> code = r.getUserAttributes();
        Iterator i = code.iterator();
        while(i.hasNext()){
            AttributeType a = (AttributeType) i.next();
            if(a.getName().equals("name"))
                return a.getValue();
        }
        return "N/A";
    }

    private static String findGroupName(String id){
        System.out.println(id);
        Table t = db.getTable("group");
        return t.getItem("id", id).get("name").toString();
    }
}
